# ----------------------------------------------------------------------------------------------------------------------
# FILE DESCRIPTION
# ----------------------------------------------------------------------------------------------------------------------

# File:  setup.py
# Author:  Billy Carson
# Date written:  01-06-2022
# Last modified:  01-06-2022

"""
Description:  Setup Python file.
"""


# ----------------------------------------------------------------------------------------------------------------------
# IMPORT STATEMENTS
# ----------------------------------------------------------------------------------------------------------------------

# Import statements
import setuptools


# ----------------------------------------------------------------------------------------------------------------------
# SETUP
# ----------------------------------------------------------------------------------------------------------------------

with open('README.md', 'r', encoding='utf-8') as fh:
    readme_description = fh.read()

setuptools.setup(
    name='pytorch-beta-divergence',
    version='0.0.1',
    author='Billy Carson',
    author_email='wec14@duke.edu',
    description='PyTorch implementation of the beta divergence loss.',
    long_description=readme_description,
    long_description_content_type='text/markdown',
    keywords=[
        'pytorch',
        'beta divergence',
        'beta',
        'divergence',
        'distance',
        'itakura-saito',
        'itakura saito',
        'itakura',
        'saito',
        'kl divergence',
        'kl',
        'kullback-leibler',
        'kullback',
        'leibler',
    ],
    url='https://github.com/wecarsoniv/pytorch-beta-divergence',
    project_urls={
        'Issue Tracker': 'https://github.com/wecarsoniv/pytorch-beta-divergence/issues',
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    package_dir={'': 'src'},
    packages=setuptools.find_packages(where='src'),
    python_requires='>=3.6',
    install_requires=[
        'numpy',
        'scipy',
    ],
)

